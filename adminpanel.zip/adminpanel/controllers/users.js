var connection = require('./../config');
module.exports.userslist = function(req,res){
		connection.query("SELECT id,name,email,date_format(created_date,'%d/%m/%y') as created_date FROM users",function(err,data){
			if(err){
				throw err;
			}else{
				res.render('admin/users',{
					title: 'Users',
					description: 'Users Description',
					usersData: data
				});
			}
		});
}
module.exports.addUser = function(req,res){
				res.render('admin/addUser',{
					title: 'Add User',
					description: 'Add User Description'
				});
}

module.exports.saveuser = function(req,res){
	var name=req.body.name;
	var email=req.body.email;
	var password=req.body.password;
        
	var data = {    
		name    : name,
		email   : email,
		password   : password 
	};
	
	connection.query("INSERT INTO users set ? ",data, function(err, rows){
	  if (err)
	  console.log("Error inserting : %s ",err );
	  res.redirect('/admin/users');
	});
	
}

module.exports.edituser = function(req, res){
    
  var id = req.params.id;

     connection.query('SELECT * FROM users WHERE id = ?',[id],function(err,rows)
        {
            
            if(err)
                console.log("Error Selecting : %s ",err ); 
				res.render('admin/addUser',{
					title: 'Update User',
					description: 'Update User Description',
					UserData: rows
				});
                           
         });

};

module.exports.delete_user = function(req,res){
          
    var id = req.params.id;
        connection.query("DELETE FROM users  WHERE id = ? ",[id], function(err, rows)
        {
            
             if(err)
                 console.log("Error deleting : %s ",err );
            
             res.redirect('/admin/users');
             
        });
        
};


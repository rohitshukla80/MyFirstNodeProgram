var connection = require('./../config');
module.exports.authenticate=function(req,res){
    var email=req.body.email;
    var password=req.body.password;
	
    connection.query('SELECT * FROM users WHERE email = ?',[email], function (error, results, fields) {
      if (error) {
		  res.render('admin/login', { message: 'there are some error with query' });
      }else{
        if(results.length >0){
            if(password==results[0].password){
				sess = req.session;
				sess.email = req.body.email;
				sess.name = req.body.name;
                res.redirect('/admin/dashboard');
            }else{
                res.render('admin/login', { message: 'Email and password does not match' });
            }
        }
        else{
			res.render('admin/login', { message: 'Email does not exits.' });
        }
      }
    });
}
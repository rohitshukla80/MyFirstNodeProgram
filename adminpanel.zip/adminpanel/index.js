/*var express = require('express');
var app = express();
var port = process.env:PORT || 1991;
var passport = require('passport'); //authenticating with different methods
var flash = require('flash'); //passing session flashdata messages

var bodyParser   = require('body-parser');
var session      = require('express-session');
var cookieParser = require('cookie-parser');

var configDB = require('./config/database.js');

app.use(cookieParser()); // read cookies (needed for auth)
app.use(bodyParser()); // get information from html forms

app.set('view engine', 'ejs'); // set up ejs for templating

// required for passport
app.use(session({ secret: 'ilovescotchscotchyscotchscotch' })); // session secret
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
app.use(flash()); // use connect-flash for flash messages stored in session
*/

var express = require("express");
var app = express();
var expressSession = require('express-session');
var cookieParser = require('cookie-parser'); // the session is stored in a cookie, so we use this to parse it
var bodyParser = require('body-parser'); // get information from html forms

app.use(expressSession({secret: 'dsfgsfsdfsdfsdfsdfsdfsdf',
resave:true,
saveUninitialized:true
}));

app.set('view engine','ejs');
app.set('port','8012');
app.set('baseurl','localhost:'+app.get('port'));
app.use(express.static(__dirname+'/public'));
app.use(cookieParser());
var authenticateUser = require('./controllers/auth-user');
var users = require('./controllers/users');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

function restrict(req,res,next){
	if(req.session.email){
		next();
	}else{
		res.redirect('/admin/login');
	}
}

/* route to handle login and registration */
app.get('/admin', function(req, res) {
	sess = req.session;
	if(sess.email){
		res.redirect('/admin/dashboard');
	}else{
		res.redirect('/admin/login');
	}
});
app.get('/admin/login', function(req, res) {
	sess = req.session;
	if(sess.email){
		res.redirect('/admin/dashboard');
	}else{
		res.render('admin/login',{
			title: 'Login',
			description: 'Login Description',
			message : ''
		});
	}
});
app.get('/admin/dashboard',restrict, function(req, res) {
		res.render('admin/dashboard',{
			title: 'Dashboard',
			description: 'Dashboard Description',
		});	
});
app.post('/admin/login/authenticate',authenticateUser.authenticate);

app.get('/admin/logout',function(req,res){
	req.session.destroy(function(err) {
	  if(err) {
		console.log(err);
	  } else {
		res.redirect('/admin/');
	  }
	});
});

app.get('/admin/users',restrict,users.userslist);
app.get('/admin/users/add',restrict, users.addUser);
app.post('/admin/users/add',restrict, users.saveuser);
app.get('/admin/users/edit/:id',restrict, users.edituser); 
app.get('/admin/users/delete/:id',restrict, users.delete_user);
//app.post('/admin/users/edit/:id',restrict,users.save_edit);
/*
app.get('/admin/users/add',restrict, users.add);
app.post('/admin/users/add',restrict, users.save);//route delete user
app.get('/admin/users/delete/:id',restrict, users.delete_user);//edit user route , get n post
app.get('/admin/users/edit/:id',restrict, users.edit); 
app.post('/admin/users/edit/:id',restrict,users.save_edit);
*/

app.listen(app.get('port'));